# iv8 Runtime Cheatsheet

Use this Provider reference after web-protocol-recovery's `references/embedded-browser-runtime-playbook.md` has established that a local embedded host is the right delivery shape and `iv8` is the chosen runtime.

## Contents

- What this file is for
- Minimal setup
- Choose the right load path
- Time control
- Keep network local
- Patch the smallest faithful surface
- Probe before you patch
- Fast decision cues
- Evidence to keep
- Common traps

## What this file is for

Use `iv8` as a narrow local host when JavaScript still needs browser-visible semantics and the final collector can still live in Python.

Best-fit uses:

- bootstrap scripts that need host state before one concrete artifact appears
- probe chains where `navigator`, `document.cookie`, timers, or request hooks change the output
- local egress capture where `netLog` reveals the decisive URL, body, headers, or outbound `Cookie`
- narrow host-surface gaps such as `canvas`, WebGL, layout, or `Function.prototype.toString`

Use it only when the result can be handed back to Python.

Use `iv8` for browser-visible semantics such as:

- `navigator`, `screen`, `location`, `document.cookie`
- DOM lifecycle or parser order
- timers, microtasks, or request hooks
- wrapper observation through local XHR or fetch state
- native-looking surfaces such as `canvas`, WebGL, layout, or `Function.prototype.toString`

Do not let `iv8` become the HTTP client, browser profile, or hidden final collector.
Python still owns live egress, retries, parsing, persistence, and scaling.
If you cannot name the single artifact you expect to recover, you probably do not need `iv8` yet.

## Minimal setup

Start with the smallest environment that proves the branch you care about:

- `location`
- `navigator.userAgent`
- timezone when time or locale checks matter

Do not cargo-cult hundreds of fingerprint fields before the probe chain proves they matter.

Useful `iv8` primitives from the tutorial:

- `JSContext(environment=..., config=..., time_mode=...)`
- `__iv8__.page.load(snapshot)`
- `document.documentElement.innerHTML = ...`
- `__iv8__.eventLoop.sleep/advance/drain`
- `ctx.add_resource(...)`
- `__iv8__.netLog.entries`
- `__iv8__.wrapNative(fn, name)`
- `ctx.with_devtools(..., watch_apis=[...])`

## Choose the right load path

Use `page.load(snapshot)` when:

- inline or external scripts must execute
- lifecycle events matter
- request hooks or parser order matter
- the HTML response, headers, and resource map are part of the bootstrap contract

Use plain DOM insertion such as `innerHTML` when:

- you only need structure or constants from HTML
- script execution is unnecessary
- you want the cheapest possible host surface

Rule:

- if the artifact depends on lifecycle or self-issued requests, prefer `page.load`
- if parsing alone is enough, do not pay the lifecycle cost

## Time control

Default to `time_mode="logical"` when you want fast deterministic bootstrap.

Use `time_mode="system"` only when:

- the target checks real elapsed time
- PoW or timestamp deltas depend on wall clock semantics

Preferred flow:

1. load the page or script
2. advance only the time you can justify
3. harvest the artifact or egress boundary as soon as it becomes stable

Useful moves:

- `sleep(ms)` to advance logical time and flush queued work
- `drain()` when time should not advance further
- `advance(total, step)` when frame-sized progression matters

## Keep network local

Community `iv8` should be treated as local bootstrap only.

Preferred replay shape:

1. JavaScript bootstrap runs locally in `iv8`
2. inspect `__iv8__.netLog.entries` for the decisive URL, body, headers, outbound `Cookie`, or other wrapper-mutated request fields
3. Python sends the real network request
4. `ctx.add_resource(...)` injects the captured response only when the local runtime must continue
5. extract the final artifact back to Python

If the egress `Cookie` header differs from `document.cookie` or a client-managed jar, trust the egress record for replay and treat the stored state as only one input to that wire result.

Do not let `iv8` quietly own live business HTTP.

## Patch the smallest faithful surface

Reach for these in order:

1. environment fields such as `location`, `navigator`, timezone
2. narrow property adapters with `Object.defineProperty`
3. native-looking shims with `__iv8__.wrapNative(...)`
4. targeted probes or wrappers on the exact host surface

Common examples from the tutorial that generalize well:

- `MessageChannel`
- `SharedArrayBuffer`
- `navigator.connection`
- `PerformanceObserver.supportedEntryTypes`
- specific `document.createElement` branches

Rule:

- patch the exact missing surface
- keep the shape native-looking when reflection matters
- if one instance hook is bypassed, move to the shared boundary instead of adding more one-off stubs

## Probe before you patch

High-value ways to discover the missing surface:

- `ctx.with_devtools(..., watch_apis=[...])` for focused API access proof
- `Proxy` wrappers around `window`, `navigator`, `document`, or a narrow host object
- local wrappers on `canvas`, WebGL, layout, or descriptor reads

Treat these as evidence surfaces, not default instrumentation:

- `Object.keys`
- `Reflect.ownKeys`
- descriptor reads
- `Function.prototype.toString`
- `document.cookie`
- `canvas.toDataURL`
- `getComputedStyle`

If cookie, storage, script tags, or resource maps barely change the output, suspect native-surface gaps before replaying more bootstrap.

## Fast decision cues

Use `page.load` when local output changes after lifecycle or resource execution.

Use the same session, effective origin, and relevant discovery headers when reacquiring linked bootstrap assets or runner scripts.

Use `innerHTML` when the needed value is already in the DOM and scripts add no value.

Use `wrapNative` when reflection or `[native code]` checks matter.

Use `netLog.entries` when the runtime already emits the real wrapped request.

Use `add_resource` when the runtime needs a local response to continue but Python should still own the real HTTP.

Use `watch_apis` or `Proxy` when you still do not know which host surface is decisive.

Use `iv8` only until one decisive artifact is stable enough for Python replay.

## Evidence to keep

Record these artifacts:

- the exact HTML or bootstrap response used
- the resource map you supplied
- the minimal environment overrides
- timer mode and explicit event-loop advances
- the decisive host probes you observed
- the extracted cookie, token, URL, or body
- fixed-input checks proving local output matches the live sample

## Common traps

- overfilling environment fingerprints before proving the missing branch
- using `page.load` when static DOM parsing would do
- reacquiring linked bootstrap assets under a fresh client or guessed origin instead of the same session chain that discovered them
- replaying full async bootstrap when injected issued state already unblocks the runtime
- reusing one signed suffix, header, token, or `Cookie` sample across page, keyword, referer, timestamp, or body changes without replay proof
- keeping a broad `iv8` harness after one getter, cookie, or egress boundary is enough
- mistaking a host-fidelity gap for a bad signer when the local blob is much shorter or structurally cleaner than the live one
- letting `iv8` become a stealth browser replacement instead of a narrow host runtime
- treating `iv8` as the final HTTP executor instead of a local bootstrap bridge
